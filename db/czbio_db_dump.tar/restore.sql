--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.11
-- Dumped by pg_dump version 13.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE czbio_db;
--
-- Name: czbio_db; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE czbio_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'C' LC_CTYPE = 'C.UTF-8';


ALTER DATABASE czbio_db OWNER TO postgres;

\connect czbio_db

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: fibonacci; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA fibonacci;


ALTER SCHEMA fibonacci OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: fibo_values; Type: TABLE; Schema: fibonacci; Owner: postgres
--

CREATE TABLE fibonacci.fibo_values (
    number_id integer NOT NULL,
    fibon_value bigint NOT NULL
);


ALTER TABLE fibonacci.fibo_values OWNER TO postgres;

--
-- Data for Name: fibo_values; Type: TABLE DATA; Schema: fibonacci; Owner: postgres
--

COPY fibonacci.fibo_values (number_id, fibon_value) FROM stdin;
\.
COPY fibonacci.fibo_values (number_id, fibon_value) FROM '$$PATH$$/3004.dat';

--
-- Name: fibo_values fibo_values_pkey; Type: CONSTRAINT; Schema: fibonacci; Owner: postgres
--

ALTER TABLE ONLY fibonacci.fibo_values
    ADD CONSTRAINT fibo_values_pkey PRIMARY KEY (number_id);


--
-- PostgreSQL database dump complete
--

